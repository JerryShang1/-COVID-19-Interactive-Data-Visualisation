
const maxNum = 160000;
const width = 1200;
const height = 660;
const margin = {top:40, bottom: 100, left: 40, right: 40};
const rectWid = 15;
const labelSize = 15;

countryList = ["America","France","Britain","Italy","Canada","Korea"];
countryIndex=0;

var arrayX = new Array();
    
function yAxis(g,yt,inData) {
    g.attr("transform", `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(yt).ticks(null, inData.format))
        .attr("font-size", '15px')
}

function xAxis(g,xt,inData) {
	  for (i = 0; i < 30; i++) { 
        arrayX.push(i+1);
    }
    g.attr("transform", `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(xt).tickFormat(i => arrayX[i]))
       // .call(d3.axisBottom(xt).ticks(i+=>i+1))
        .attr("font-size", '15px')
}
svg = d3.select('#d3-container') //leg-container
    .append('svg')
    .attr('height', height - margin.top - 40)//margin.bottom)
    .attr('width', width - margin.left - margin.right)
    .attr('viewBox', [0, 0, width, height]);
    

        
function DrawD3Graph(dataIn){
    svg.remove();
    
    svg = d3.select('#d3-container') //leg-container
    .append('svg')
    .attr('height', height - margin.top - 40)//margin.bottom)
    .attr('width', width - margin.left - margin.right)
    .attr('viewBox', [0, 0, width, height]);
    
    const x = d3.scaleBand()
    .domain(d3.range(dataIn.length))
    .range([margin.left, width - margin.right])
    .paddingInner(0.1);


const y = d3.scaleLinear()
    .domain([0, maxNum])
    .range([height - margin.bottom, margin.top])

    const legend1 = [
{label:"New diagnosis this month", margin:280},
{label:"New diagnosis last month", margin:520}
];
    const legend2 = [
{label:"Number of confirmed cases"}
];
 
    svg
        .append("g")
        .attr("fill", 'royalblue')
        .selectAll("rect")
        //.data(data.sort((a, b) => d3.descending(a.TotalCofirm, b.TotalCofirm)))
        .data(dataIn)
        .join("rect")
            .attr("x", (d,i) => x(i)+(x.bandwidth()-rectWid)/2-rectWid/2)
            .attr("y", d => y(d.LastNewC))
            .attr('height', d=> y(0) - y(d.LastNewC))
            .attr('width', rectWid);
                 
    svg
        .append("g")
        .attr("fill", 'orange')
        .selectAll("rect")

        .data(dataIn)
        .join("rect")
            .attr("x", (d,i) => x(i)+(x.bandwidth()-rectWid)/2+rectWid/2)
            .attr("y", d => y(d.NewCof))
            .attr('height', d=> y(0) - y(d.NewCof))
            .attr('width', rectWid);



    svg.append("g").call(yAxis,y,dataIn);
    svg.append("g").call(xAxis,x,dataIn);
    
    svg
        .append("g")
        .attr("fill", 'royalblue')
        .selectAll("rect")
        .data(legend1)
        .join("rect")
            .attr("x", 380)
            .attr("y", height-50)
            .attr('height', rectWid)
            .attr('width', rectWid); 
        
    svg
        .append("g")
        .attr("fill", 'orange')
        .selectAll("rect")
        .data(legend2)
        .join("rect")
            .attr("x", 620)
            .attr("y", height-50)
            .attr('height', rectWid)
            .attr('width', rectWid); 

    svg
        .append("g")
        .attr("fill", 'black')
        .selectAll("text")
        .data(legend1)
        .join("text")
          .text(d=> (d.label))
          .attr("x", d=> (d.margin)+120)
          .attr("y",  height-40)
          .attr("font-size", 15);

    svg.node();
}


function sendRestfulGetB(){
	  countryIndex = countryIndex-1;
    if(countryIndex < 0){
    	countryIndex=0;
    }
    msg = document.getElementById('countryName');
    msg.innerHTML = countryList[countryIndex];
    
    var doubanURL = 'http://127.0.0.1:5000/todos/'+countryList[countryIndex];
    $.ajax({
        url: doubanURL,
        type: 'Get',
        data: '',
        dataType: 'JSON',
        crossDomain: false,
        success: function(data){
           // msg = document.getElementById('show');
          //  msg.innerHTML = syntaxHighlight(data);
            DrawD3Graph(data);
            console.log(data);
        }
    });

}
function sendRestfulGetN(){
	  countryIndex = countryIndex+1;
    if(countryIndex > countryList.length-1){
    	countryIndex=countryList.length-1;
    }
    msg = document.getElementById('countryName');
    msg.innerHTML = countryList[countryIndex];
    
    var doubanURL = 'http://127.0.0.1:5000/todos/'+countryList[countryIndex];
    $.ajax({
        url: doubanURL,
        type: 'Get',
        data: '',
        dataType: 'JSON',
        crossDomain: false,
        success: function(data){
           // msg = document.getElementById('show');
          //  msg.innerHTML = syntaxHighlight(data);
            DrawD3Graph(data);
            console.log(data);
        }
    });

}

function syntaxHighlight(json) {
    if (typeof json != 'string') {
        json = JSON.stringify(json, undefined, 2);
    }
    json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function(match) {
        var cls = 'number';
        if (/^"/.test(match)) {
            if (/:$/.test(match)) {
                cls = 'key';
            } else {
                cls = 'string';
            }
        } else if (/true|false/.test(match)) {
            cls = 'boolean';
        } else if (/null/.test(match)) {
            cls = 'null';
        }
        return '<span class="' + cls + '">' + match + '</span>';
    });
}

    var doubanURL = 'http://127.0.0.1:5000/todos/'+countryList[countryIndex];
    $.ajax({
        url: doubanURL,
        type: 'Get',
        data: '',
        dataType: 'JSON',
        crossDomain: false,
        success: function(data){
           // msg = document.getElementById('show');
          //  msg.innerHTML = syntaxHighlight(data);
            DrawD3Graph(data);
            console.log(data);
        }
    });