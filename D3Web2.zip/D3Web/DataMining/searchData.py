
import openpyxl
import requests
import time
import json
import urllib.parse


head0 = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36'
}
url = 'https://api.inews.qq.com/newsqa/v1/automation/modules/list?modules=FAutoforeignList'

sess = requests.Session()

r = sess.get(url=url, headers=head0, proxies={"https://": '222.110.147.50:3128'}).text
res = json.loads(r, strict=False)['data']
res_list = res['FAutoforeignList']


list_name = []

for li in res_list:
    name = li['name']
    list_name.append(name)


start = time.time()

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/83.0.4103.61 Safari/537.36 "
}


def dataSavedFunction(url):
 
    response = requests.get(url, headers=headers)
    jsonResponse = response.json()
   
    dataCollection = []
    for result in jsonResponse["data"]:
        dataCollection.append([
            result["date"],
            result["confirm"],
            result["dead"],
            result["heal"],
            result["confirm_add"]
        ])
    return dataCollection



def dataToExcel():
   #try:
       
       wb = openpyxl.Workbook()
       for name in list_name:
           wb_sheet = wb.create_sheet(name)
           wb_sheet.append(["covDate", "totalConfirm", "totalDeath", "totalRecover", "NewConfirm"])
         
          # nameIndex = list_name.index(name)
           rows = dataSavedFunction("https://api.inews.qq.com/newsqa/v1/automation/foreign/daily/list?country="+urllib.parse.quote(name)+"&")
           for j in rows:
               wb_sheet.append(j)

       wb.save("totalCrawlResult.xlsx")
       wb.close()
	#except PermissionError:


if __name__ == "__main__":
    dataToExcel()
    end = time.time()
    print("Use times：", end - start, "second")

