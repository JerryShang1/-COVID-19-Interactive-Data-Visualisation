import xlrd #need ver 1.2.0
import csv

def readFile(filePath,tabIndex):
    try:
        fileType = filePath.split(".")[-1]
       # print(f'{filePath}\t{fileType}')
        if fileType == 'xlsx' or fileType=='xls':
            res = []
            wb = xlrd.open_workbook(filePath)
            sh = wb.sheet_by_index(tabIndex)
            title = []
            for item in sh.row_values(0):
                title.append(item)
            data = []
           
            [[data.append({title[index]: transfer(sh.row_values(it)[index]) for index in range(0,len(title))})] for it in range(1,sh.nrows)]
            return data
        elif fileType == "csv":
            data = []
            with open(filePath) as csvfile:
                rows = csv.reader(csvfile)  
                title = next(rows)  
                [[data.append({title[index]: transfer(it[index]) for index in range(0, len(title))})] for it in rows]
            return data
        else:
            return -1
    except(EOFError):
        print("Error: transform！")
        print(EOFError)
        return -1


def transfer(string):
    try:
        if float(string) == float(int(float(string))):
            return int(string)
        else:
            return float(string)
    except:
        pass
    return True if string.lower() == 'true' else (False if string.lower() == 'false' else string)

